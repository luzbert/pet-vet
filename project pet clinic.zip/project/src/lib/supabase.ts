import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your .env file.')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Database = {
  public: {
    Tables: {
      pets: {
        Row: {
          id: string
          name: string
          species: string
          breed: string
          age: number
          owner_name: string
          owner_phone: string
          owner_email: string
          medical_history: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          species: string
          breed: string
          age: number
          owner_name: string
          owner_phone: string
          owner_email: string
          medical_history?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          species?: string
          breed?: string
          age?: number
          owner_name?: string
          owner_phone?: string
          owner_email?: string
          medical_history?: string
          updated_at?: string
        }
      }
      appointments: {
        Row: {
          id: string
          pet_id: string
          appointment_date: string
          appointment_time: string
          reason: string
          status: string
          notes: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          pet_id: string
          appointment_date: string
          appointment_time: string
          reason: string
          status?: string
          notes?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          pet_id?: string
          appointment_date?: string
          appointment_time?: string
          reason?: string
          status?: string
          notes?: string
          updated_at?: string
        }
      }
      staff: {
        Row: {
          id: string
          name: string
          role: string
          email: string
          phone: string
          specialization: string
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          role: string
          email: string
          phone: string
          specialization?: string
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          role?: string
          email?: string
          phone?: string
          specialization?: string
        }
      }
    }
  }
}