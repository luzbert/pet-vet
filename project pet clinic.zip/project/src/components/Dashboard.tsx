import React, { useEffect, useState } from 'react'
import { PawPrint, Calendar, Users, TrendingUp, Clock, Heart } from 'lucide-react'
import { supabase } from '../lib/supabase'

interface Stats {
  totalPets: number
  todayAppointments: number
  totalStaff: number
  pendingAppointments: number
}

export default function Dashboard() {
  const [stats, setStats] = useState<Stats>({
    totalPets: 0,
    todayAppointments: 0,
    totalStaff: 0,
    pendingAppointments: 0
  })
  const [recentAppointments, setRecentAppointments] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      // Fetch stats
      const [petsResult, appointmentsResult, staffResult] = await Promise.all([
        supabase.from('pets').select('id', { count: 'exact' }),
        supabase.from('appointments').select('*'),
        supabase.from('staff').select('id', { count: 'exact' })
      ])

      const today = new Date().toISOString().split('T')[0]
      const todayAppointments = appointmentsResult.data?.filter(
        apt => apt.appointment_date === today
      ).length || 0

      const pendingAppointments = appointmentsResult.data?.filter(
        apt => apt.status === 'scheduled'
      ).length || 0

      setStats({
        totalPets: petsResult.count || 0,
        todayAppointments,
        totalStaff: staffResult.count || 0,
        pendingAppointments
      })

      // Fetch recent appointments with pet details
      const { data: appointments } = await supabase
        .from('appointments')
        .select(`
          *,
          pets (name, owner_name)
        `)
        .order('created_at', { ascending: false })
        .limit(5)

      setRecentAppointments(appointments || [])
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  const statCards = [
    {
      title: 'Total Pets',
      value: stats.totalPets,
      icon: PawPrint,
      color: 'bg-blue-500',
      bgColor: 'bg-blue-50'
    },
    {
      title: "Today's Appointments",
      value: stats.todayAppointments,
      icon: Calendar,
      color: 'bg-green-500',
      bgColor: 'bg-green-50'
    },
    {
      title: 'Staff Members',
      value: stats.totalStaff,
      icon: Users,
      color: 'bg-purple-500',
      bgColor: 'bg-purple-50'
    },
    {
      title: 'Pending Appointments',
      value: stats.pendingAppointments,
      icon: Clock,
      color: 'bg-orange-500',
      bgColor: 'bg-orange-50'
    }
  ]

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Welcome to PetCare Clinic Management System</p>
        </div>
        <div className="flex items-center space-x-2 bg-blue-50 px-4 py-2 rounded-lg">
          <Heart className="h-5 w-5 text-blue-600" />
          <span className="text-blue-700 font-medium">Caring for pets since 2020</span>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card, index) => {
          const Icon = card.icon
          return (
            <div key={index} className={`${card.bgColor} p-6 rounded-xl border border-gray-100`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">{card.title}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{card.value}</p>
                </div>
                <div className={`${card.color} p-3 rounded-lg`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Recent Appointments */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Recent Appointments</h2>
        </div>
        <div className="p-6">
          {recentAppointments.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No appointments found</p>
          ) : (
            <div className="space-y-4">
              {recentAppointments.map((appointment) => (
                <div
                  key={appointment.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <div className="bg-blue-100 p-2 rounded-lg">
                      <Calendar className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">
                        {appointment.pets?.name || 'Unknown Pet'}
                      </p>
                      <p className="text-sm text-gray-600">
                        Owner: {appointment.pets?.owner_name || 'Unknown Owner'}
                      </p>
                      <p className="text-sm text-gray-500">
                        {appointment.appointment_date} at {appointment.appointment_time}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        appointment.status === 'completed'
                          ? 'bg-green-100 text-green-800'
                          : appointment.status === 'scheduled'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}
                    >
                      {appointment.status}
                    </span>
                    <p className="text-sm text-gray-600 mt-1">{appointment.reason}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}